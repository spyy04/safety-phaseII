#! /bin/bash

# On the RPi a GPIO is used to reset the packet forwarder and if reset_pkt_fwd is set
# to true, a script is called to do this. 
#
reset_cmd="./reset_lgw.sh"
cmd="./lora_pkt_fwd"
configFile="local_conf.json"
eui_cmd="./generate_gweui.sh"

name=`basename $0`
stdout_log="/tmp/$name.log"
stderr_log="/tmp/$name.err"
network_log="/tmp/$name.network"

# Check whether need to generate GW_EUI
$eui_cmd $configFile >> "/tmp/$name.eui"   

# Test the connection, wait if needed.
while [[ $(ping -c1 www.qq.com 2>&1 | grep " 0% packet loss") == "" ]]; 
do 
    echo "[Gateway]: Waiting for internet connection..." > "$network_log"
    sleep 3 
done
echo "[Gateway]: Internet is connnected" > "$network_log"

# Reset the SX1301 chip
echo "Reset $name"
$reset_cmd start 22 >> "$stdout_log" 2>> "$stderr_log"

# Fire up the packet_forwarder
echo "Starting $name"
$cmd >> "$stdout_log" 2>> "$stderr_log" 

