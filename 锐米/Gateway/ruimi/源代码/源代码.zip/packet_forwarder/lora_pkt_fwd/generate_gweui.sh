#!/bin/bash

# This script is a helper to update the Gateway_ID field of given
# JSON configuration file, as a EUI-64 address generated from the 48-bits MAC
# address of the device it is run from.
#
# Usage examples:
#       ./update_gwid.sh ./local_conf.json

generate_gweui() {
    # generate gateway ID from its MAC address
    GW_EUI=$(ip link show eth0 | awk '/ether/ {print $2}' | awk -F\: '{print $1$2$3"FFFE"$4$5$6}')
    GW_EUI=${GW_EUI^^}
    echo "EUI get from EMAC is: $GW_EUI"

    # fetch gateway ID from "local_conf.json" 
    FILE_EUI=$(grep "gateway_ID" $1 | awk -F\" '{print $4}')
    FILE_EUI=${FILE_EUI^^}
    echo "EUI get from file is: $FILE_EUI"

    # compare if the "GW_EUI" equal "FILE_EUI", as well as write into file if NOT equal.
    if [ $GW_EUI != $FILE_EUI ]
    then
      sed -i 's/\(^\s*"gateway_ID":\s*"\).\{16\}"\s*\(,\?\).*$/\1'$GW_EUI'"\2/' $1
      echo "Gateway_ID set to "$GW_EUI" in file "$1
    fi
}

if [ $# -ne 1 ]
then
    echo "Usage: $0 [filename]"
    echo "  filename: Path to JSON file containing Gateway_ID for packet forwarder"
    exit 1
fi 

generate_gweui $1

exit 0
