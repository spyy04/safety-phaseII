/* Get high and low 4 bits of a byte, as 0x34 => 0x03 and 0x04 */
#define GET_BYTE_HIGH4(Byte)    (((Byte) >> 4) & 0x0F)
#define GET_BYTE_LOW4(Byte)    ((Byte) & 0x0F)

/* Convert data(0~15) to ASCII, as 1=>'1', a=>'a' */
#define DATA_2_ASCII(Data)    ((Data) < 10 ? ((Data) + '0') : ((Data) + 'A' - 10))

/* convert binary to hex-string, like as: [0x12] => ['1']['2'][' '] */
int bin_to_hex(const uint8_t *in, int size, char *out, int max_len)
{
    #define BIN_2_BYTES    3 /* [0x12] => ['1']['2'][' '] */

    int    cnt;
    int    yield_len;
    uint8_t    data;

    /* Avoid overflow */
    yield_len = size * BIN_2_BYTES;
    if (max_len < yield_len)
    {
        return -1;
    }

    for (cnt = 0; cnt < size; ++cnt)
    {
        data = in[cnt];
        out[cnt * BIN_2_BYTES + 0] = DATA_2_ASCII(GET_BYTE_HIGH4(data));
        out[cnt * BIN_2_BYTES + 1] = DATA_2_ASCII(GET_BYTE_LOW4(data));
        out[cnt * BIN_2_BYTES + 2] = ' ';
    }
    
    return yield_len;
}
